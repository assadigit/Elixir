# Next Session Prompt — Elixir

You are continuing work on the existing Elixir Python desktop application. Read these project documents before acting:

- `docs/ELIXIR_FINAL_DASHBOARD_DESIGN_SPEC.md`
- `AI_IMPLEMENTATION_INSTRUCTIONS.md`
- `SESSION_WORKFLOW.md`
- The latest `docs/NEXT_SESSION_PROMPT.md` and changelog in the repository, if present.

## Current milestone
[Insert milestone ID and name.]

## Previous session summary
[Summarize completed work and decisions.]

## Repository state
- Branch: [branch]
- Last commit: [hash and message]
- Push status: [pushed/not pushed and why]
- Working tree: [clean/dirty; list user changes that must be preserved]

## Files changed
[List paths and purpose.]

## Tests and visual QA
[List exact commands, outcomes, environments, screenshots, and failures.]

## Known issues and constraints
[List unresolved issues, risks, and out-of-scope work.]

## Your task this session
[State one approved milestone and concrete tasks.]

## Acceptance criteria
[List measurable completion conditions.]

## Required process
1. Inspect current Git status and preserve all existing user changes.
2. Read the source before assuming architecture or behavior.
3. Work only on the stated milestone.
4. Run relevant tests and visual checks; report exact results.
5. Review the diff and commit coherent changes using repository conventions.
6. Push only to the intended existing branch if configured; never force-push.
7. Do not publish a release or deploy without explicit user approval.
8. Update docs/changelog and replace this handoff with the next session's complete prompt.
9. Finish with the full end-of-session report required by `SESSION_WORKFLOW.md`.

## Explicitly do not
- Redesign the Full Conversion Wizard unless this session is separately approved for that milestone and the actual wizard screenshots are available.
- Invent product features or show mock data.
- Delete experimental code merely because its tabs are hidden.
- Change conversion behavior, backend integrations, or the Qt binding as part of visual work.
