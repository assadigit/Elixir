# Elixir UI/UX Implementation Package

This package is the approved starting point for implementing the Elixir desktop application's visual foundation and dashboard in its existing Python/Qt codebase.

## Package contents

- `docs/ELIXIR_FINAL_DASHBOARD_DESIGN_SPEC.md` — approved design specification and definition of done.
- `AI_IMPLEMENTATION_INSTRUCTIONS.md` — master instructions for an AI coding agent working incrementally across sessions.
- `SESSION_WORKFLOW.md` — milestone sequence, commit/push/release rules, testing and handoff protocol.
- `templates/NEXT_SESSION_PROMPT_TEMPLATE.md` — required handoff prompt template.
- `assets/` — cropped PNG concepts for the hero and botanical motifs.
- `reference/approved_dashboard_visual_reference.png` — approved dashboard visual reference.
- `reference/asset_sheet_reference.png` and `reference/branding_reference_sheet.png` — original generated asset/branding sheets for visual reference.

## Important

The images are visual assets and concepts, not proof of existing product features. The generated crops may contain soft edges or imperfect details. Inspect them before shipping. Do not use the asset-sheet images as screenshots or as a source of UI text. Recreate interface icons with a consistent vector icon set where possible; do not crop the tiny icon samples and use them as production icons.

The implementation agent must inspect the actual repository before making changes. The exact Qt binding, tool inventory, navigation, backend controls, and build process are not assumed by this package.

## Start here

1. Give the coding agent the entire extracted package and access to the Elixir repository.
2. Ask it to execute **M0 — Repository Reconnaissance** only.
3. Review and approve the M0 report before authorizing M1 implementation.
4. Continue one milestone per session, following `SESSION_WORKFLOW.md`.
