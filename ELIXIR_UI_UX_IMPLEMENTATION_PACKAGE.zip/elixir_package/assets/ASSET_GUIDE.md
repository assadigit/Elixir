# Asset Guide

All PNGs in this folder are generated visual concepts supplied for the Elixir dashboard direction.

| File | Intended use | Notes |
|---|---|---|
| `hero_books_quill.png` | Optional Full Conversion hero illustration | Transparent crop from a generated asset sheet; inspect edge quality and crop before use. |
| `leaf_mark_concept.png` | Brand exploration only | Not a finalized logo or vector mark; requires review before production use. |
| `botanical_landscape.png` | Optional subtle decorative background | Use sparingly and only if it does not compete with content. |
| `botanical_branch.png` | Optional small botanical accent | Avoid repetitive decoration. |
| `leaf_emblem_tile.png` | Brand exploration / tile concept | Not a production app icon without review. |

The full generated sheets are in `reference/`. They are visual references, not production-ready component libraries. Do not crop tiny icon samples into production UI icons. Prefer a consistent vector icon family (SVG or the project's existing Qt-compatible icon system).
