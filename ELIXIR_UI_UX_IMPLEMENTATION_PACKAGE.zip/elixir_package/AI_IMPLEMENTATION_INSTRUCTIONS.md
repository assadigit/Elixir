# Master AI Coding-Agent Instructions — Elixir UI/UX Redesign

You are implementing an approved visual redesign of **Elixir**, an existing Python desktop application. Your task is to improve the visual foundation and dashboard in the existing codebase while preserving all real functionality.

## 1. Read these sources first

Treat these files as the design authority:

1. `docs/ELIXIR_FINAL_DASHBOARD_DESIGN_SPEC.md`
2. `reference/approved_dashboard_visual_reference.png`
3. `SESSION_WORKFLOW.md`

Use `reference/asset_sheet_reference.png` and `reference/branding_reference_sheet.png` as inspiration only. The standalone PNGs in `assets/` are optional visual assets. Do not assume every asset belongs in the final UI.

If instructions conflict, preserve existing application behavior and the explicit scope boundaries in this document. Report conflicts instead of silently choosing a risky interpretation.

## 2. Product understanding

Elixir is a knowledge-processing application. Its central promise is helping users turn books, articles, and documents into clear, structured knowledge.

Brand line: **Knowledge, distilled into clarity.**

The Full Conversion Wizard is the primary product workflow. Approximately 99% of operations may happen through it, but do not encode that estimate as UI copy. The dashboard should make Full Conversion the obvious starting point while keeping secondary tools easy to find.

## 3. Non-negotiable scope

### In scope

- M1: shared visual foundation, design tokens, typography, icons, reusable components, light and dark themes.
- M2: dashboard layout, fixed compact sidebar, prominent Full Conversion hero, compact secondary-tool grid, appropriate decluttering of the header.
- M3: visual polish, responsive behavior, accessibility basics, and regression testing.
- M4: documentation, changelog, commits, push, and release handoff according to repository conventions and user authorization.

### Out of scope

- Redesigning the Full Conversion Wizard in this phase.
- Changing its existing 10-step sequence or behavior.
- Changing conversion algorithms, output generation, model calls, backend integrations, or tool behavior.
- Deleting experimental tools or their underlying code.
- Adding product features that are not already present and verified.

The Wizard redesign is a separate later milestone and requires the user's screenshots of the actual wizard interface.

## 4. Mandatory repository reconnaissance before edits

Do not assume PyQt5, PyQt6, or PySide6. Inspect and report:

- Exact Qt binding and version.
- Python version and dependency management.
- App entry point and startup flow.
- Main window, dashboard, navigation, and tool-launch architecture.
- Complete implemented tool inventory and exact user-facing names.
- Existing theme implementation and persistence mechanism.
- Existing settings and backend indicator locations/actions.
- Experimental tabs and how they are registered.
- Existing asset, font, and icon resources.
- Minimum window dimensions and current layout strategy.
- Build, packaging, release, and test commands.
- Current Git branch, working tree state, remotes, and recent commit conventions.

Run the existing tests or baseline checks. Record failures that existed before your changes. Do not “fix” unrelated issues during reconnaissance.

Create or update a short implementation map in the repository documentation. Never guess at source files or APIs; inspect before editing.

## 5. Approved visual system

Follow the final design specification for exact starting color tokens, type hierarchy, layout, and component behavior.

High-level identity:

- Warm ivory/cream, charcoal, muted forest green, and sage.
- Modern sans-serif typography throughout; Inter where available, Segoe UI on Windows, then Noto Sans/Arial fallback.
- Monochrome outline icons with restrained accent use.
- Minimal, premium, editorial, academic, credible.
- No generic blue-purple AI gradients, neon accents, excessive shadows, glow, glass effects, or decorative clutter.
- Both light and dark themes must be intentionally designed and tested.

Centralize semantic design tokens. Do not scatter hard-coded colors, font sizes, and radii throughout widget stylesheets. Use the existing architecture and Qt binding. Prefer Qt layouts and size policies over fixed coordinates.

## 6. Dashboard requirements

### Sidebar

- Compact and fixed.
- Always visible.
- Show both icons and text labels.
- Group tools only after verifying the actual tool inventory.
- Use consistent outline icons and clear active, hover, focus, and disabled states.
- Do not show experimental destinations in primary navigation.
- Do not delete experimental code, routes, or functionality.

### Header

- Keep it minimal.
- Move backend indicators (e.g. Ollama, llama.cpp, LM Studio) and less-used actions out of the prominent header only after tracing their current behavior and finding an appropriate existing Settings/status location.
- Do not remove access to controls or invent a new backend-management feature.

### Full Conversion hero

- This is the single dominant dashboard action.
- Use an editorial split layout: concise text and CTA balanced with a restrained visual.
- Retain the approved book/quill/knowledge visual direction but reduce decorative weight.
- One primary CTA: **Start Conversion** (or the exact existing label if the app uses a different established term).
- Do not duplicate Full Conversion as a card in Quick Tools.
- Keep the hero compact enough that the secondary tools section begins within the initial view at a typical 1280×800 window where feasible.

Suggested headline: “Turn documents into clear, structured knowledge.”
Suggested supporting copy: “Transform books, articles, and documents into useful summaries and structured outputs.”
Verify every claim against actual supported functionality before using it.

### Quick Tools

- Compact grid beneath the hero.
- Secondary tools only; never repeat Full Conversion.
- Consistent card sizing, icon treatment, title hierarchy, and concise optional description.
- Subtle borders/surface contrast; no heavy shadows.
- Entire card may be clickable if consistent with existing navigation patterns.
- Reflow naturally with available width.
- Include only tools verified in source code and intended for dashboard access.

Potential names to verify, not assume: Summarization, Document → Markdown, Translation, Markdown Styler, Packets of Knowledge, OCR Service, PDF/DOCX Cutter, Image Extractor, TTS, podcast creation, transcription.

## 7. Assets and image handling

- Inspect PNG alpha channels and crop boundaries before use.
- Prefer the isolated `assets/hero_books_quill.png` for a hero visual only if its quality, transparency, and scaling are acceptable.
- `leaf_mark_concept.png` is a concept, not a finalized vector logo. Do not treat it as an approved production brand mark without review.
- Botanical assets are optional supporting motifs. Use sparingly.
- Do not place the entire asset sheet into the application UI.
- Do not use tiny raster icon samples from the sheet as production icons. Use a consistent Qt-compatible vector icon set or SVG resources.
- Keep image assets at suitable resolution and device-pixel scaling; avoid blurry enlargement.
- If an asset looks poor on the actual background, omit it rather than forcing it into the interface.
- Do not generate or add more assets without checking whether the existing assets suffice and whether the user has authorized more image work.

## 8. Functionality preservation

Preserve:

- Existing navigation destinations and launch behavior for real tools.
- Existing backend connections and controls.
- Existing settings/configuration behavior.
- Full Conversion's existing 10-step sequence.
- Support for selecting multiple output types in one conversion run.
- Existing persistence and user preferences.

Never add mock data, fake statuses, fake recent jobs, a fictional library, presets, queues, history, or onboarding flows. A screenshot is a visual reference, not evidence that those features exist.

## 9. Engineering standards

- Follow the project's established code style and architecture.
- Keep changes modular and focused on the current milestone.
- Reuse components and theme tokens; avoid duplicated styles.
- Do not replace the Qt binding or introduce a new UI framework.
- Avoid fixed-position layouts that break on resize or DPI scaling.
- Preserve keyboard navigation, focus visibility, useful tab order, accessible labels, and practical hit targets.
- Do not rely on color alone to convey state.
- Handle missing optional fonts/assets gracefully.
- Avoid adding dependencies unless necessary; explain and justify any new dependency.
- Do not reformat or rewrite unrelated modules.
- Do not silently alter data formats, settings schemas, or conversion behavior.

## 10. Testing requirements

Before and after each milestone, run the relevant existing tests and checks. Add focused tests where practical, but do not invent a test framework without inspecting the repository.

For UI validation, test at least:

- 1280×800 and 1440×900.
- A narrower supported desktop window.
- Windows scaling 100%, 125%, and 150% where available.
- Light and dark themes.

Check:

- Sidebar labels and icons remain readable.
- Hero text, CTA, and illustration do not overlap.
- Quick Tools reflow without clipping.
- No unnecessary horizontal scrolling.
- Long tool labels remain usable.
- Buttons and cards have visible hover/focus/pressed states.
- Theme switching updates all dashboard components.
- Navigation launches the correct existing tools.
- Experimental tabs are hidden from primary navigation but their code remains intact.
- Wizard and conversion behavior are unchanged.
- Backend integrations and settings remain functional.

Capture before/after screenshots when possible. Clearly distinguish pre-existing test failures from regressions introduced by your changes.

## 11. Git, commits, push, and releases

Follow `SESSION_WORKFLOW.md` exactly.

- Never overwrite or discard the user's uncommitted work.
- Inspect `git status` before edits and before every commit.
- Do not reset, force-push, rewrite shared history, or delete branches.
- Use small, descriptive commits per completed milestone or coherent subtask.
- Run tests before committing.
- Review the diff for accidental changes, secrets, generated files, and unrelated edits.
- Push only to the existing intended remote/branch and only when credentials and repository configuration are valid.
- Do not create a GitHub release, tag, publish a package, or deploy without explicit user authorization for that release/deployment.
- If push is blocked, report the exact reason and provide the local commit hash; do not claim it was pushed.
- If release is not authorized, prepare release notes but stop before publishing.

## 12. Required end-of-session report and next-session prompt

At the end of EVERY work session, provide:

1. Milestone and objective.
2. What was inspected/implemented.
3. Files added, changed, or removed.
4. Tests/checks run and exact results.
5. Screenshots or visual QA performed.
6. Known issues, risks, and deferred work.
7. Git status, commit hash(es), push status, and release status.
8. Documentation/changelog updates.
9. Recommended next milestone.
10. A complete, copy-paste-ready prompt for the next AI session.

Update `docs/NEXT_SESSION_PROMPT.md` (or the repository's existing equivalent) with that next prompt. Also update the changelog and milestone notes where appropriate. Never leave the next agent to infer what happened.

## 13. Session boundaries

- Session 1: M0 reconnaissance only; no UI implementation until the user reviews the report.
- Session 2: M1 visual foundation, if M0 is approved.
- Session 3: M2 dashboard, if M1 is tested and approved.
- Session 4: M3 polish and regression testing.
- Session 5: M4 documentation, commit/push and release preparation; publishing only with approval.

The number of sessions may change if the codebase requires it, but never skip testing or handoff. If a milestone is too large, split it into smaller coherent tasks and document the split.

## 14. Definition of done

The redesign is complete only when it matches the approved design specification, the fixed labeled sidebar and refined hero are implemented, secondary tools appear in a compact grid without duplicate Full Conversion, only verified features are shown, experimental destinations are hidden but not deleted, both themes work, responsive/DPI checks pass, existing functionality remains intact, documentation is current, and the milestone is committed with a complete handoff.

**Final principle:** Make complex document processing feel clear, calm, and intentional. Elixir should be memorable through restraint, not decoration.
