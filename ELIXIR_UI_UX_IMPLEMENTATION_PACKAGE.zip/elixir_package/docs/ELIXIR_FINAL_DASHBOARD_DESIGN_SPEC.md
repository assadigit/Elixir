# Elixir --- Final Dashboard Design Specification

**Product:** Elixir v0.6.69\
**Scope:** M1 Visual Foundation and M2 Dashboard\
**Status:** Approved design direction; implementation details must be
verified against the repository\
**Out of scope:** Redesigning the 10-step Full Conversion Wizard

## 1. Product objective

Elixir helps users turn books, articles, and documents into clear,
structured knowledge they can understand and use.

**Brand line:** *Knowledge, distilled into clarity.*

The dashboard should feel premium, calm, academic, credible, modern, and
practical as a Windows desktop application. It must not resemble a
generic AI dashboard, a marketing landing page, or a collection of
unrelated utilities.

## 2. Approved decisions

  -----------------------------------------------------------------------
  Area                                Decision
  ----------------------------------- -----------------------------------
  Overall style                       Minimal, premium, editorial,
                                      academic

  Hero                                Editorial and visual; retain the
                                      current concept with a smaller,
                                      refined illustration

  Secondary tools                     Compact, consistent grid beneath
                                      the hero

  Sidebar                             Compact and fixed, always visible
                                      with icons and labels

  Themes                              Fully supported light and dark
                                      themes

  Typography                          Modern sans-serif throughout

  Icons                               Monochrome outline with restrained
                                      accent use

  Main workflow                       Full Conversion Wizard

  Wizard workflow                     Preserve the existing 10-step
                                      behavior; redesign later

  Conversion outputs                  Preserve multiple output types per
                                      run

  Scope                               Dashboard and shared visual
                                      foundation only
  -----------------------------------------------------------------------

## 3. Visual identity

### Color direction

Use warm ivory, charcoal, muted forest green, and sage. These are
starting tokens; validate contrast and rendering in the actual Qt
application.

#### Light theme

  Token              Suggested value   Usage
  ------------------ ----------------- -------------------------------------
  `background`       `#F6F5F0`         Main background
  `surface`          `#FFFFFF`         Cards and content surfaces
  `surface-subtle`   `#EFEEE7`         Secondary surfaces
  `text-primary`     `#252923`         Primary text
  `text-secondary`   `#70756D`         Supporting text
  `border`           `#E2E1D9`         Separators and outlines
  `accent`           `#3F634D`         Primary actions and selected states
  `accent-hover`     `#34543F`         Hover state
  `accent-subtle`    `#E6EDE6`         Quiet accent backgrounds
  `icon`             `#626A60`         Default icons

#### Dark theme

  Token              Suggested value   Usage
  ------------------ ----------------- -------------------------------------
  `background`       `#20231F`         Main background
  `surface`          `#292D28`         Cards and content surfaces
  `surface-subtle`   `#30362F`         Secondary surfaces
  `text-primary`     `#ECEEE8`         Primary text
  `text-secondary`   `#A8AEA3`         Supporting text
  `border`           `#3B423A`         Separators and outlines
  `accent`           `#91AD91`         Primary actions and selected states
  `accent-hover`     `#A4BDA2`         Hover state
  `accent-subtle`    `#354238`         Quiet accent backgrounds
  `icon`             `#B3BBAF`         Default icons

Avoid generic blue-purple gradients, neon accents, competing accent
colors, large areas of saturated green, excessive shadows, glow, blur,
and glass effects. Green should communicate interaction and focus, not
decorate every component.

## 4. Typography

Use a modern sans-serif throughout. Preferred order: Inter (if available
and appropriately packaged), Segoe UI on Windows, then Noto Sans or
Arial. Do not use serif display headings or a serif wordmark.

  Role                Suggested size Weight
  ----------------- ---------------- -----------------
  Hero heading             26--30 px Semibold
  Section heading          16--18 px Semibold
  Tool title               14--15 px Medium/Semibold
  Body text                13--14 px Regular
  Supporting text          11--12 px Regular
  Sidebar label            12--13 px Medium

Validate font metrics and scaling in the chosen Qt binding, particularly
at Windows 125% and 150% display scaling. Avoid overly small text.

## 5. Application shell

Use a two-part shell: a compact, fixed left sidebar and a flexible main
content area. The sidebar remains visible and shows both icons and
labels; it is not icon-only and does not require a collapse interaction
in this approved version.

The main content should have sensible horizontal margins or a maximum
content width so it does not become excessively stretched on large
displays.

### Sidebar structure

Proposed information architecture, subject to repository verification:

-   Home
-   Processing
    -   Summarization
    -   Document → Markdown
    -   Translation
-   Utilities
    -   Markdown Styler
    -   Packets of Knowledge
    -   OCR Service
    -   PDF/DOCX Cutter
    -   Image Extractor
-   Settings
-   About

Only include tools and destinations that actually exist in the current
codebase. Verify exact labels and routes before implementation.

Use consistent outline icons, restrained green for the active
destination, subtle grouping, and distinct hover, focus, active, and
disabled states. Avoid putting every item in its own card.

Keep Queue, Output Scanner, Bullet Audit, and Hallucination Audit out of
primary navigation. Do not delete their underlying code, functionality,
or routes as part of this visual change.

### Header and secondary controls

Keep the header minimal. Backend indicators for Ollama, llama.cpp, LM
Studio, and less-used actions should not dominate it. Move them into
Settings or an existing appropriate status area after verifying their
current behavior. Do not remove backend controls or invent a new status
system. Avoid duplicate navigation destinations and repeated controls.

## 6. Dashboard composition

Use this hierarchy:

1.  Concise welcome or purpose statement.
2.  Prominent Full Conversion hero.
3.  Quick Tools section containing secondary tools only.

Full Conversion must not appear again as a duplicate tile in the
secondary grid.

### Hero: Full Conversion

Suggested copy:

**Heading:** Turn documents into clear, structured knowledge.

**Supporting copy:** Transform books, articles, and documents into
useful summaries and structured outputs.

**Primary action:** Start Conversion

Refine the copy to match actual product terminology; do not promise
unsupported capabilities.

Use an editorial split composition: text and action on one side, a
restrained visual on the other. Retain the knowledge/book concept from
the approved reference, but reduce its size and decorative complexity. A
visual motif may suggest extracting, organizing, or distilling
knowledge. It must support, not compete with, the heading and action.

Use a calm surface, subtle separation from the page background, and one
clear primary action. Avoid additional hero buttons unless an existing,
genuinely important action warrants them. Keep the hero prominent but
not excessively tall. At 1280 × 800, users should see the hero and at
least the beginning of the secondary tools section without unnecessary
scrolling.

### Quick Tools: compact grid

Place secondary tools beneath the hero in a compact grid.

-   Consistent card dimensions and alignment.
-   One outline icon, concise tool name, and optionally a one-line
    description.
-   Subtle borders or surface contrast rather than heavy shadows.
-   Clear hover, focus, and pressed states.
-   Cards should be usable navigation targets if consistent with the
    existing interaction model.
-   Grid reflows with available width.

Potential tools to verify against the repository: Summarization,
Document → Markdown, Translation, Markdown Styler, Packets of Knowledge,
OCR Service, PDF/DOCX Cutter, Image Extractor. Features such as TTS,
podcast creation, or transcription must only be included if confirmed in
the current version and intended for dashboard access.

## 7. Icons and illustration

Use one consistent outline icon family. Prefer simple, recognizable
symbols with consistent stroke weights and optical sizes. Use neutral
icon colors by default and accents only for active, selected, or
primary-action contexts. Avoid emoji, mixed icon families, and 3D icons.

The hero illustration should be a minimal editorial illustration with a
limited theme palette, clear silhouette, and restrained detail. Avoid
floating symbols, sparkles, decorative particles, and AI clichés.
Simplify or remove it at narrow widths if it compromises usability.

## 8. Light and dark themes

Both themes must be fully implemented. Every dashboard component must
use semantic theme tokens: cards, sidebar, buttons, borders, text,
icons, tooltips, inputs, focus states, and disabled states. Theme
switching must update the whole application consistently. Do not use
global inversion or merely darken the light palette. Preserve the same
hierarchy and spacing in both themes.

Persist the theme preference only if the existing application already
has a settings persistence mechanism or one is explicitly approved
during implementation.

## 9. Behavior constraints

This is a visual and navigation refinement, not a functional rewrite.

Preserve existing tool implementations, routes, navigation, backend
integrations, settings, configuration, the Wizard's 10-step sequence,
and support for multiple output types per conversion run.

Do not invent or introduce a document library, recent jobs/history,
presets/templates, new queue or job-management features, new backend
management capabilities, account features, or other unverified
functionality.

If first-run guidance already exists, improve its presentation only
after inspecting it. Do not invent a new onboarding flow.

## 10. Qt implementation guidance

Before implementation, inspect and document:

-   Qt binding and version (PyQt5, PyQt6, PySide6, or other).
-   Application entry point and dashboard widget.
-   Existing navigation and tool-launch mechanisms.
-   Existing theme system and persistence.
-   Font and icon resources.
-   Minimum supported window size and layout behavior.
-   Build, packaging, and test procedures.

Use reusable components and centralized theme tokens, not scattered
one-off styles. Suggested elements: application shell, sidebar
navigation item, sidebar section label, dashboard hero panel, primary
action button, Quick Tool card, section heading, theme-aware icon
helper, and shared spacing/typography/color tokens.

Follow the existing architecture. Do not introduce a new UI framework or
replace the Qt binding. Prefer Qt layouts and size policies over fixed
positioning. Ensure keyboard focus, tab order, accessible labels, and
usable hit targets. Do not rely exclusively on color to communicate
status or selection.

## 11. Responsive behavior and QA

Test at minimum:

-   1280 × 800
-   1440 × 900
-   A narrower desktop window supported by the current application
-   Windows scaling at 100%, 125%, and 150%, where available

Verify that sidebar labels remain readable; hero text and illustration
do not overlap; Quick Tools reflow without clipping; no unnecessary
horizontal scrolling appears; both themes are balanced; icons render
consistently; long labels do not break layouts; navigation opens the
correct tools; experimental tabs are absent from primary navigation
while their code remains intact; and conversion/backend behavior does
not regress.

Capture final screenshots in both themes at representative sizes.

## 12. Milestones and delivery workflow

### M0 --- Repository reconnaissance

Inspect the source, identify the Qt binding, map dashboard widgets,
tools, routes, settings, and themes, record which tools are implemented
versus experimental, establish a baseline, and run existing tests. Do
not make risky UI changes.

**Deliverable:** Repository map and code-grounded implementation plan.

### M1 --- Visual foundation

Implement centralized design tokens, typography and icon conventions,
reusable controls and styles, and both themes. Do not change tool
behavior.

**Deliverable:** Reusable theme-aware visual foundation.

### M2 --- Dashboard

Implement the compact fixed sidebar, refined Full Conversion hero,
compact secondary tools grid, and hide experimental destinations from
primary navigation. Move backend indicators and less-used actions out of
the main header where appropriate. Preserve functionality.

**Deliverable:** Functional dashboard matching this specification.

### M3 --- Polish and regression testing

Test window sizes, scaling, themes, navigation, and integrations. Fix
layout and typography issues and capture screenshots.

**Deliverable:** QA-verified dashboard.

### M4 --- Documentation and release handoff

Update relevant documentation and changelog, record decisions and known
limitations, commit and push using repository conventions, and
release/deploy only when appropriate and explicitly authorized. Prepare
a precise next-session prompt.

**Deliverable:** Documented milestone, commit, and clear handoff.

### Later milestone --- Full Conversion Wizard

Defer the Wizard redesign until the user provides screenshots of the
actual 10-step interface and the source is inspected. Preserve its
behavior and multiple-output selection.

## 13. Definition of done

-   Approved visual direction is implemented consistently.
-   Fixed sidebar displays icons and labels.
-   Full Conversion is the single dominant dashboard action.
-   Full Conversion is not duplicated in the secondary grid.
-   Secondary tools appear in a compact, consistent grid.
-   Only verified existing tools and destinations are shown.
-   Experimental tabs are hidden from primary navigation without
    deleting their code.
-   Light and dark themes work across dashboard components.
-   Backend indicators and less-used actions no longer clutter the
    header.
-   Layout works at supported desktop sizes and display scaling.
-   Existing navigation, conversion behavior, and backend integrations
    remain functional.
-   Documentation, changelog, tests, and handoff notes are updated.

## 14. Implementation guardrails

1.  **Inspect before changing.** Never infer code structure from a
    mockup.
2.  **No invented features.** A visual reference is not evidence that a
    feature exists.
3.  **No workflow redesign.** The Wizard is out of scope for M1/M2.
4.  **No functional regressions.** Navigation and integrations must
    continue to work.
5.  **No decorative excess.** Remove elements that do not improve
    hierarchy, comprehension, or usability.
6.  **No one-theme shortcuts.** Both themes require deliberate
    attention.
7.  **Modular delivery.** Complete, test, document, and commit each
    milestone before moving on.
8.  **Session handoff.** End each work session with updated
    documentation and a specific next-session prompt.

**Final design principle:** Elixir should make complex document
processing feel clear, calm, and intentional. The interface should be
memorable through its restraint, not through decoration.
