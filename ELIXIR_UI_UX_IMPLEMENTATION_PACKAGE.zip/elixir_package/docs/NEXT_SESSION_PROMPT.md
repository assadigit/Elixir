# Next Session Prompt — Start M0 Repository Reconnaissance

You are beginning the Elixir UI/UX redesign in the existing Python desktop application. Read `README.md`, `AI_IMPLEMENTATION_INSTRUCTIONS.md`, `SESSION_WORKFLOW.md`, and `docs/ELIXIR_FINAL_DASHBOARD_DESIGN_SPEC.md` in this package before touching the repository.

**This session is M0 — Repository Reconnaissance only. Do not implement UI changes yet.**

Inspect the repository and report the exact Qt binding/version, Python/dependency setup, app entry point, main window/dashboard/navigation architecture, complete verified tool inventory, experimental destinations, theme implementation/persistence, backend controls, asset/font/icon resources, minimum supported window size, build/package/release commands, tests, current Git branch/remotes/status, and commit conventions.

Run baseline tests/checks using the project's actual documented commands. Distinguish existing failures from blockers. Do not delete or modify user work, do not add dependencies, and do not infer features from the mockup.

Produce a code-grounded M1/M2 implementation plan with exact likely files/modules and risks. Update repository documentation with the reconnaissance findings and write a precise next-session prompt for M1. End with the complete handoff report required by `SESSION_WORKFLOW.md`.

Wait for the user's review/approval before beginning M1.
