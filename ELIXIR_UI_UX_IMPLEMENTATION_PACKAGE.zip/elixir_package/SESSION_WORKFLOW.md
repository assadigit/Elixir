# Elixir Multi-Session Workflow

## Milestone sequence

| Milestone | Focus | Required output | Gate before next milestone |
|---|---|---|---|
| M0 | Repository reconnaissance | Codebase map, verified tool inventory, Qt binding, baseline tests, implementation plan | User reviews and approves findings |
| M1 | Visual foundation | Theme tokens, typography, icons, reusable controls, light/dark themes | Tests pass; screenshots/theme review; commit |
| M2 | Dashboard | Fixed sidebar, refined Full Conversion hero, compact secondary grid, decluttered header | Navigation and functionality regression checks; commit |
| M3 | Polish and QA | Responsive/DPI fixes, both-theme review, regression tests, screenshots | QA report accepted; commit |
| M4 | Docs and release handoff | Updated docs/changelog, final summary, commits/push, release notes | Explicit user approval before publishing/deploying |
| Later | Wizard redesign | New Wizard design based on actual 10-step screenshots and code | Separate scope approval |

## Rules for every session

1. Start by reading the design spec, master AI instructions, latest handoff prompt, and current repository status.
2. Confirm the current branch and inspect uncommitted changes. Never overwrite user work.
3. Work only on the current approved milestone. Do not silently start the next milestone.
4. Make incremental, reviewable changes. Prefer a small number of coherent commits over one giant commit.
5. Run relevant tests and inspect the diff before committing.
6. Update documentation and changelog when behavior, architecture, design tokens, or project workflow changes.
7. Record exact commands and test outcomes; never say “tested” without stating what ran.
8. At session end, update the next-session prompt and give the user a complete handoff report.

## Commit protocol

Before committing:

- `git status --short`
- Review `git diff` and `git diff --staged`.
- Check for secrets, local config, caches, build output, temporary files, and unrelated modifications.
- Run the relevant test/build/lint commands discovered in M0.
- Stage only files belonging to the milestone.

Use descriptive commit messages, for example:

- `ui: add semantic light and dark theme tokens`
- `ui: build reusable dashboard components`
- `ui: implement refined dashboard layout`
- `test: cover dashboard navigation and theme states`
- `docs: document dashboard redesign and handoff`

Do not force-push, rewrite history, or amend existing commits unless explicitly requested.

## Push and release protocol

- Push only to the repository's existing intended remote and branch.
- Confirm push success from Git output. If it fails, state the error and local commit hash.
- A Git push is not the same as a product release.
- Prepare release notes after M3/M4, but do not publish a GitHub Release, create a public tag, upload installers, or deploy unless the user explicitly authorizes that action.
- Before an authorized release, verify versioning, changelog, build artifacts, smoke tests, and rollback considerations.

## Testing protocol

Use the test/build procedures found during M0; do not assume commands. At minimum, test relevant navigation and theme behavior, plus the app's existing test suite. Visual QA should cover 1280×800, 1440×900, a narrower supported size, light/dark themes, and Windows scaling 100/125/150% where available.

Record failures that existed before the milestone separately from newly introduced regressions. Do not claim the application was tested on an environment that was not available.

## End-of-session handoff

Every session must finish with:

- Summary of work and milestone status.
- Files changed.
- Tests and exact results.
- Visual QA/screenshots.
- Known issues and deferred items.
- Git branch/status/commit hashes and push status.
- Release/deployment status.
- Documentation/changelog updates.
- Next milestone recommendation.
- A copy-paste-ready next-session prompt saved to `docs/NEXT_SESSION_PROMPT.md` (or the repo's existing equivalent).

Do not leave incomplete or ambiguous handoffs. If work is blocked, explain the blocker and make the next prompt focus on resolving it safely.
